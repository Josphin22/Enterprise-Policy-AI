from pathlib import Path
from pypdf import PdfWriter
from pypdf.generic import (
    DictionaryObject,
    NameObject,
    DecodedStreamObject,
)

def create_pdf(file_path: Path):
    writer = PdfWriter()

    # Font resource
    font_dict = DictionaryObject()
    font_sub = DictionaryObject()
    font_sub[NameObject("/Type")] = NameObject("/Font")
    font_sub[NameObject("/Subtype")] = NameObject("/Type1")
    font_sub[NameObject("/BaseFont")] = NameObject("/Helvetica")
    font_dict[NameObject("/F1")] = writer._add_object(font_sub)

    resources = DictionaryObject()
    resources[NameObject("/Font")] = font_dict

    # Page 1
    page1 = writer.add_blank_page(width=612, height=792)
    page1_text = (
        b"BT /F1 14 Tf 50 720 Td (Enterprise Leave Policy Manual) Tj "
        b"0 -30 Td /F1 11 Tf (1. Annual Vacation Leave) Tj "
        b"0 -20 Td (All full-time employees are entitled to 15 days of annual paid vacation leave.) Tj "
        b"0 -20 Td (Employees may carry forward a maximum of 5 unused vacation days into next year.) Tj ET"
    )
    stream1 = DecodedStreamObject()
    stream1.set_data(page1_text)
    page1[NameObject("/Contents")] = writer._add_object(stream1)
    page1[NameObject("/Resources")] = resources

    # Page 2
    page2 = writer.add_blank_page(width=612, height=792)
    page2_text = (
        b"BT /F1 14 Tf 50 720 Td (2. Sick and Medical Leave) Tj "
        b"0 -30 Td /F1 11 Tf (Employees are provided with 10 days of paid medical and sick leave annually.) Tj "
        b"0 -20 Td (Medical certificate is required for absences exceeding 3 consecutive business days.) Tj ET"
    )
    stream2 = DecodedStreamObject()
    stream2.set_data(page2_text)
    page2[NameObject("/Contents")] = writer._add_object(stream2)
    page2[NameObject("/Resources")] = resources

    with open(file_path, "wb") as f:
        writer.write(f)

if __name__ == "__main__":
    out_dir = Path(__file__).parent
    pdf_path = out_dir / "Leave_Policy.pdf"
    create_pdf(pdf_path)
    print(f"Generated {pdf_path}")
